<?php
$servername = "remotemysql.com";
$username = "NEgfqq1rAL";
$database = "NEgfqq1rAL";
$password = "RaHX1T8Qe9";
?>