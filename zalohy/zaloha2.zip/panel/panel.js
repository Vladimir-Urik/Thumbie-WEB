function logined(){
    location.href = 'https://discordapp.com/api/oauth2/authorize?client_id=699959562454827009&redirect_uri=https%3A%2F%2Fprivate.greenlandmc.eu%2Ftajny-projekt%2FGGGEDR%2FThumbie%2Fpanel%2Fintegrations%2Fdiscord%2FOAuth2%2Flogin.php&response_type=code&scope=identify%20guilds%20email';
}

function odhlasit() {
    document.cookie = "user_id=null;expires=0;path=/";
    document.cookie = "user_name=null;expires=0;path=/";
}