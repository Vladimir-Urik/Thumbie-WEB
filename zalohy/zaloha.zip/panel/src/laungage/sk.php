<?php
$Title = "Thumbie &bull; Domov";
$Welcome = "Je čas prejsť na Thumbieho.";
$Invite = "Pridať na server";
$Dashboard = "Panel";
$Home = "Domov";
$About = "O Thumbim";
$Features = "Vlastnosti";
$Doc = "Wiki";
$Commands = "Príkazy";
$Tutorial = "Tutoriály";
$sett = "Panel";
$Login = "Prihlásiť sa";
$Des = "Thumbie je plne prispôsobiteľný viacúčelový bot - jediný bot, ktorého budete potrebovať<br />Je vybavený automatickým moderovaním, memes, administráciou, hudbou a oveľa viac !!";
$FOB = "Vlastnosti";
$FOS = "Tu je výpis Thumbieho super vlastností!";
$OneCardTitle = "Auto Moderátor";
$OneCardSubtitle = "Nemáte veľa moderátorov? Máte na servery spammerov alebo uživatelov ktorý porušuju pravidla? Thumbie vám pomôže ich potrestať! A na vašom servery bude klud!";
$TwoCardTitle = "Prispôsobenosť";
$TwoCardSubtitle = "Thumbie is completely customizable - you can customize whatever you want. From color of embeds, through footer of messages, to all texts - it's up to you!";
$ThreeCardTitle = "Hudba";
$ThreeCardSubtitle = "We offer the best music without lags. You can listen to YouTube, Spotify, even to radio! You can choose between many controls - again, it's up to you!";
$FourCardTitle = "Memes";
$FourCardSubtitle = "Have you ever wanted the dankest memes? We have them! You can choose from many subreddits, or even from your own! Just invite Thumbie and watch!";
$FiveCardTitle = "Giveaways";
$FiveCardSubtitle = "Have you ever wanted to do a giveaway, but with completely customizable messages? It's here! With Thumbie, your giveaways will be the best from all.";
$SixCardTitle = "Reaction roles";
$SixCardSubtitle = "Are you tired from setting each members a role? Now you don't have to! Thumbie offers reaction roles! When users reacts to a message, they will get a role!";
$SevenCardTitle = "Uvítanie";
$SevenCardSubtitle = "Do you want something different than the default Discord's welcomes? Do you want to customize it? You can! The only thing you need to do is to invite Thumbie!";
$EightCardTitle = "Prihlasovanie";
$EightCardSubtitle = "Have someone changed his name or edited a message and you've wanted to see the original? With our logging system, you won't miss anything!";
$Servers = "Servery";
$Users = "Uživatelia";
$Channels = "Kanály";
$StartCardTitle = "Začnite teraz!";
$StartCardSubtitle = "Pozvi Thumbieho - Jedinný bot ktorého budete potrebovať!";
$BTNStarted = "Pozvať!";
$CreatedBy = "Vytvoril <a href=\"https://GGGEDR.eu\"> GGGEDR</a> s <a style='color: orange'>♡</a>";
//NEW
//ERRORS
$ERRFourZeroFour = "ERROR 404";
$ERRFourZeroFourSub = "Táto stránka neexistuje alebo k nej nemáte prístup<br />Ak si myslíte že ide o chybu kontaktujte prosím Administrátora";
$ReturnToHome = "Späť na hlavnú stránku";
//COOKIES
$Cookies = "Používame súbory <strong>cookies</strong> kvôli výberu jazyku a pre funkčnosť nášho webu";
$MoreInfo = "Viac info";
$BTNCookies = "Okey!";
?>