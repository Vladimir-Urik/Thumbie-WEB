<?php
$Title = "Thumbie &bull; Home";
$Welcome = "It's time to switch to Thumbie.";
$Invite = "Add to server";
$Dashboard = "Dashboard";
$Home = "Home";
$Login = "Login";
$About = "About";
$Features = "Features";
$Doc = "Documentation";
$Commands = "Commands";
$Tutorial = "Tutorials";
$sett = "Server settings";
$Login = "LOGIN";
$Des = "Thumbie is completely customizable multi-purpose bot - the only bot you'll ever need<br />It features auto-moderation, memes, administration, music and much more!!";
$FOB = "Features";
$FOS = "List of Thumbie's awesome features";
$OneCardTitle = "Auto moderation";
$OneCardSubtitle = "Don't you have enough moderators? Thumbie can do all the work! Are you annoyed from all the spammers and people who swear? Thumbie is here to help you!";
$TwoCardTitle = "Customization";
$TwoCardSubtitle = "Thumbie is completely customizable - you can customize whatever you want. From color of embeds, through footer of messages, to all texts - it's up to you!";
$ThreeCardTitle = "Music";
$ThreeCardSubtitle = "We offer the best music without lags. You can listen to YouTube, Spotify, even to radio! You can choose between many controls - again, it's up to you!";
$FourCardTitle = "Memes";
$FourCardSubtitle = "Have you ever wanted the dankest memes? We have them! You can choose from many subreddits, or even from your own! Just invite Thumbie and watch!";
$FiveCardTitle = "Giveaways";
$FiveCardSubtitle = "Have you ever wanted to do a giveaway, but with completely customizable messages? It's here! With Thumbie, your giveaways will be the best from all.";
$SixCardTitle = "Reaction roles";
$SixCardSubtitle = "Are you tired from setting each members a role? Now you don't have to! Thumbie offers reaction roles! When users reacts to a message, they will get a role!";
$SevenCardTitle = "Welcomer";
$SevenCardSubtitle = "Do you want something different than the default Discord's welcomes? Do you want to customize it? You can! The only thing you need to do is to invite Thumbie!";
$EightCardTitle = "Logging";
$EightCardSubtitle = "Have someone changed his name or edited a message and you've wanted to see the original? With our logging system, you won't miss anything!";
$Servers = "Servers";
$Users = "Users";
$Channels = "Channels";
$StartCardTitle = "Get started now!";
$StartCardSubtitle = "Invite Thumbie - the only bot you'll ever need!";
$BTNStarted = "Get started!";
$CreatedBy = "Created by <a href=\"https://GGGEDR.eu\"> GGGEDR</a> with <a style='color: orange'>♡</a>";
//NEW
//ERRORS
$ERRFourZeroFour = "ERROR 404";
$ERRFourZeroFourSub = "This page doesn't exist or you do not have access to it.<br /> If you think this is a mistake, contact an administrator.";
$ReturnToHome = "Return to homepage";
$Cookies = "We use <strong>cookies</strong> to remember your chosen language and to ensure you get the best experience.";
$MoreInfo = "More info";
$BTNCookies = "Got it!";
?>