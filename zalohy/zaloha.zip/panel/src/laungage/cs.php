<?php
$Title = "Thumbie &bull; Domů";
$Welcome = "Je čas přepnout na Thumbieho.";
$Invite = "Přidat na server";
$Dashboard = "Panel";
$Home = "Domů";
$Login = "Přihlásit se";
$About = "O botovi";
$Features = "Funkce";
$Doc = "Dokumentace";
$Commands = "Příkazy";
$Tutorial = "Tutoriály";
$sett = "Nastavení bota";
$Login = "PŘIHLÁSIT SE";
$Des = "Thumbie je kompletně přizpůsobitelný víceúčelový bot - jediný bot, kterého kdy budeš potřebovat<br />Nabízí automatickou moderaci, memy, administraci, hudbu a spoustu dalšího!";
$FOB = "Funkce bota";
$FOS = "Seznam úžasných funkcí Thumbieho";
$OneCardTitle = "Auto mod";
$OneCardSubtitle = "Nemáš dost moderátorů? Thumbie může udělat všechnu práci za ně! Jsi otrávený ze všech těch spamerů a lidí co nadávají? Už nemusíš! Je tu totiž Thumbie, aby ti pomohl!";
$TwoCardTitle = "Přizpůsobitelnost";
$TwoCardSubtitle = "Thumbie je kompletně přizpůsobitelný - můžeš si přizpůsobit téměr cokoli. Od barvy zpráv, přes patičku zpráv až po všechny texty - je to jen na tobě! Tak čím začneš?";
$ThreeCardTitle = "Hudba";
$ThreeCardSubtitle = "Nabízíme nejlepší hudbu bez záseků. Můžeš poslouchat YouTube, Spotify nebo dokonce i rádio! Můžeš si vybrat mezi spoustou ovládání - zase, je to jen na tobě!";
$FourCardTitle = "Memy";
$FourCardSubtitle = "Vždycky jsi chtěl ty nejvíc dank memy? My je máme! Můžeš si vybrat ze spousty subredditů, dokonce ze svých vlastních! Prostě pozvi Thumbieho a sleduj! Jo a vyslovuje se to mím.";
$FiveCardTitle = "Soutěže";
$FiveCardSubtitle = "Vždycky jsi chtěl udělat soutěž, ale mít kompletně přizpůsobitelné zprávy? Je to tu! S Thumbiem budeš mít ty nejlepší soutěže ze všech!";
$SixCardTitle = "Reakční role";
$SixCardSubtitle = "Jsi otrávený z nastavování role každému členovi? Už nemusíš! Thumbie nabízí reakční role! Jakmile nějaký uživatel klikne na reakci u zprávy, dostane roli.";
$SevenCardTitle = "Vítač";
$SevenCardSubtitle = "Chceš něco jiného než výchozí uvítání Discordu? Chceš si to přizpůsobit? Nyní můžeš! Jediná věc, kterou musíš udělat je pozvat Thumbieho na tvůj server!";
$EightCardTitle = "Záznamy";
$EightCardSubtitle = "Změnil si někdo jméno nebo upravil zprávu a ty chceš vidět tu původní? S naším záznamovým systémem už ti nic neunikce! Tak pozvi Thumbieho!";
$Servers = "Servery";
$Users = "Uživatelé";
$Channels = "Kanály";
$StartCardTitle = "Začni nyní!";
$StartCardSubtitle = "Pozvi Thumbieho - jediného bota, kterého kdy budeš potřebovat!";
$BTNStarted = "Začít!";
$CreatedBy = "Vytvořil <a href=\"https://GGGEDR.eu\"> GGGEDR</a> s <a style='color: orange'>♡</a>";
//NEW
//ERRORS
$ERRFourZeroFour = "CHYBA 404";
$ERRFourZeroFourSub = "Tato stránka neexistuje nebo k ní nemáš přístup. Pokud si myslíš, že je to chyba, kontaktuj administrátora.";
$ReturnToHome = "Vrátit se domů";
$Cookies = "Pro překlady používáme <strong>cookies</strong>.";
$MoreInfo = "Více informací";
$BTNCookies = "Chápu!";
?>