<?php

namespace Discord\OAuth;

class DiscordRequestException extends \Exception
{}